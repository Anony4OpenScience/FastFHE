#include <filesystem>
#include <iostream>
#include "openfhe.h"

#include "ciphertext-ser.h"
#include "scheme/ckksrns/ckksrns-ser.h"
#include "ciphertext-ser.h"
#include "cryptocontext-ser.h"
#include "key/key-ser.h"
#include <thread>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "Utils.h"
#include <fstream>  
#include <algorithm>

#include <sys/stat.h>
#include <sys/types.h>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <thread>

using namespace lbcrypto;
using namespace std;
using namespace utils;
namespace fs = std::filesystem;


using Ptxt = Plaintext;                 
using Ctxt = Ciphertext<DCRTPoly>;      

int generate_context;
int verbose;   //Controls the verbosity of program output. The initial value is 0, indicating that detailed information is not output by default.
string input_filename;


void check_arguments(int argc, char *argv[]);
void executeResNet20();
void print_max_min_value(const Ctxt& in);
void save_vector_to_txt(const std::vector<double>& vec, const std::string& filename);
void append_vector_to_txt(const std::vector<double>& vec, const std::string& filename);
void append_vector_first_element_to_txt(const std::vector<double>& vec, const std::string& filename);

vector<double> read_image(const char *filename);

Ctxt initial_layer(const Ctxt& in);
Ctxt layer1(const Ctxt& in);
Ctxt layer2(const Ctxt& in);
Ctxt layer3(const Ctxt& in);
Ctxt final_layer(const Ctxt& in);

class FHEController 
{
    CryptoContext<DCRTPoly> context;

public:
    int circuit_depth;
    int num_slots;

    FHEController() {}

    /*
     * Context Generation / Loading
     */
    void generate_context(int log_ring, int log_scale, int log_primes, int digits_hks, int cts_levels, int stc_levels, int relu_degree, bool serialize = false);
    void load_context(bool verbose = true);

    /*
     * Bootstrapping and rotation key generation / loading
     */
    void generate_bootstrapping_keys(int bootstrap_slots);
    void generate_rotation_keys(vector<int> rotations, bool serialize = false, string filename = "");
    void generate_bootstrapping_and_rotation_keys(vector<int> rotations,int bootstrap_slots,bool serialize,const string& filename);

    void load_bootstrapping_and_rotation_keys(const string& filename, int bootstrap_slots, bool verbose);
    void load_rotation_keys(const string& filename, bool verbose);
    void clear_bootstrapping_and_rotation_keys(int bootstrap_num_slots);
    void clear_rotation_keys();
    void clear_context(int bootstrapping_key_slots);

    /*
     * CKKS Encoding / Decoding / Encryption / Decryption
     */
    Ptxt encode(const vector<double>& vec, int level, int plaintext_num_slots);
    Ptxt encode(double val, int level, int plaintext_num_slots);
    Ctxt encrypt(const vector<double>& vec, int level = 0, int plaintext_num_slots = 0);
    Ctxt encrypt_ptxt(const Ptxt& p);
    Ptxt decrypt(const Ctxt& c);
    vector<double> decrypt_tovector(const Ctxt& c, int slots);

    /*
     * Homomorphic Operations.
     */
    Ctxt add(const Ctxt& c1, const Ctxt& c2);
    Ctxt mult(const Ctxt& c, double d);
    Ctxt mult(const Ctxt& c, const Ptxt& p);
    Ctxt bootstrap(const Ctxt& c, bool timing = false);
    Ctxt bootstrap(const Ctxt& c, int precision, bool timing = false);
    Ctxt silu(const Ctxt& c, double scale, bool timing = false);
    Ctxt relu_wide(const Ctxt& c, double a, double b, int degree, double scale, bool timing = false);
    
    /*
     * Convolution and Batch Normalization Layers
     */
    Ctxt convbn_initial(const Ctxt &in, double scale = 1, bool timing = false);

    Ctxt convbn(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);
    Ctxt convbn2(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);
    Ctxt convbn3(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);

    Ctxt convbn1632sx(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);
    Ctxt convbn1632dx(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);
    Ctxt convbn3264sx(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);
    Ctxt convbn3264dx(const Ctxt &in, int layer, int n, double scale = 1, bool timing = false);

    Ctxt rotsum1(const Ctxt &in);
    Ctxt rotsum2(const Ctxt &in);

    
    
    string parameters_folder = "NO_FOLDER";
    int relu_degree = 3;

private:
    KeyPair<DCRTPoly> key_pair;
    vector<uint32_t> level_budget = {4, 4};  
};

FHEController controller;

int main(int argc, char *argv[])
{
    
    check_arguments(argc, argv);
    verbose = 2;

    std::string dirPath = "../keys";
    struct stat info;
    
    if (stat(dirPath.c_str(), &info) != 0) 
    {

        #if defined(_WIN32)
            _mkdir(dirPath.c_str());
        #else
            mkdir(dirPath.c_str(), 0777); 
        #endif
    } else if (!(info.st_mode & S_IFDIR)) {

        std::cerr << dirPath << " exists but is not a directory" << std::endl;
        exit(1);
    }
    
    if (generate_context > 0) {
        controller.generate_context(18, 60, 59, 2, 3, 3, 3, true);  
        
        //Generating rotation keys
        cout << "Context generation completed. Proceeding to generate bootstrapping and rotation keys." << endl;

        //Rotation keys for Layer 1
        controller.generate_bootstrapping_and_rotation_keys({-512, -387, -386, -385, -384, -259, -258, -257, -256, -131, -130, -129, -128, -4, -3, -2, -1, 256,128,4,2,1, 512},16384,true,"rotations-layer1.bin");
        cout << "Rotation keys for Layer 1 have been generated." << endl;
        controller.clear_context(16384);
        controller.load_context(false);

        //Rotation keys for downsampling in Layer 2
        controller.generate_rotation_keys({-641, -640, -517, -516, -515, -514, -513, -512, -389, -388,-387, -386, -385, -384, -261, -260, -259, -258, -257, -256, -133, -132, -131, -130, -129, -128, -5, -4, -3, -2, -1, 1, 2, 4, 128, 256, 512},true,"rotations-layer2-downsample.bin");
        cout << "Rotation keys for downsampling in Layer 2 have been generated." << endl;
        controller.clear_context(0);
        controller.load_context(false);
        //Rotation keys for Layer 2
        controller.generate_bootstrapping_and_rotation_keys({8,-8,1024,-1024,512,256,128,4,2,1,-641, -640, -517, -516, -515, -514, -513, -512,-389, -388,-387,-386, -385, -384,-261,-260,-259,-258, -257, -256, -133, -132, -131, -130, -129, -128, -5, -4, -3, -2, -1},16384,true,"rotations-layer2.bin");
        cout << "Rotation keys for Layer 2 have been generated" << endl;
        controller.clear_context(16384);
        controller.load_context(false);
        //Rotation keys for downsampling in Layer 3
        controller.generate_rotation_keys({8,-8,1024,-1024,512,256,128,4,2,1,-7,-6,-5, -4, -3, -2, -1,-135,-134,-133, -132, -131, -130, -129, -128,-263,-262,-261,-260,-259,-258, -257, -256,-391,-390,-389, -388,-387,-386, -385, -384,-519,-518,-517, -516, -515, -514, -513, -512,-647,-646,-645,-644,-643,-642,-641, -640,-768,-769,-770,-771,-772,-773,-774,-775,-896,-897,-898,-899,-900,-901,-902,-903},true,"rotations-layer3-downsample.bin");
        cout << "Rotation keys for downsampling in Layer 3 have been generated." << endl;
        controller.clear_context(0);
        controller.load_context(false);
        //Rotation keys for Layer 3
        controller.generate_bootstrapping_and_rotation_keys({16,-16,2048,-2048,512,256,128,4,2,1,-7,-6,-5, -4, -3, -2, -1,-135,-134,-133, -132, -131, -130, -129, -128,-263,-262,-261,-260,-259,-258, -257, -256,-391,-390,-389, -388,-387,-386, -385, -384,-519,-518,-517, -516, -515, -514, -513, -512,-647,-646,-645,-644,-643,-642,-641, -640,-768,-769,-770,-771,-772,-773,-774,-775,-896,-897,-898,-899,-900,-901,-902,-903},16384,true,"rotations-layer3.bin");
        cout << "Rotation keys for Layer 3 have been generated." << endl;
        controller.clear_context(16384);
        controller.load_context(false);

        //Rotation keys for the final fully-connected layer
        controller.generate_rotation_keys({8192,4096,2048,64,32,16,512,256,128,4,2,1}, true, "rotations-finallayer.bin");
        cout << "Rotation keys for the final layer have been generated." << endl;
        controller.clear_context(0);
        controller.load_context(false);

        cout << "Context created correctly." << endl;

        exit(0);
    } else {
        controller.load_context(verbose > 1);
    }
    
    while(1)
    {
        executeResNet20();
    }
    
    /*
    std::vector<std::thread> threads;
    // Creating and launching multiple threads
    for (int i = 0; i < 2; ++i) {
        threads.push_back(std::thread(executeResNet20));  
    }

    // Waiting for all threads to complete execution.
    for (auto& t : threads) {
        t.join();  
    }
    */
}

void executeResNet20(){
    //Starting ResNet-20 classification
    cout << "Starting ResNet-20 classification." << endl;
    //All five layers of ciphertexts.
    Ctxt firstLayer, resLayer1, resLayer2, resLayer3, finalRes;
    //Reading image data.
    if (input_filename.empty()) {
        std::vector<std::string> image_files;
        

        for (const auto& entry : fs::directory_iterator("../inputs/")) {
            if (entry.is_regular_file()) {
                std::string filename = entry.path().filename().string();
                image_files.push_back(entry.path().string());
            }
        }


        if (!image_files.empty()) {
            std::srand(std::time(0));  
            input_filename = image_files[std::rand() % image_files.size()]; 
            if (verbose >= 0) {
                std::cout << "You did not set any input, I use " << input_filename << "." << std::endl;
            }
        } else {
            std::cerr << "No images found in ../inputs/!" << std::endl;
        }
    } else {
        if (verbose >= 0) {
            std::cout << "I am going to encrypt and classify " << input_filename << "." << std::endl;
        }
    }

    //3x32x32 data packed into a single dense ciphertext, 128*128=16384.
    vector<double> input_image = read_image(input_filename.c_str());
    save_vector_to_txt(input_image, "output.txt");

    //Encrypting the loaded image data using the specified initial layer level.
    Ctxt in = controller.encrypt(input_image, controller.circuit_depth - 9 - controller.relu_degree);
    cout << "输入数据加密完成" <<endl;
    //Reading the previously generated rotation keys for Layer 1.
    controller.load_bootstrapping_and_rotation_keys("rotations-layer1.bin", 16384, verbose > 1);
    cout << "Reading of Layer 1 rotation keys completed." <<endl;
    
    //Initial Layer:
    auto start = start_time();
    firstLayer = initial_layer(in);
    print_duration(start, "initial 1ayer took:");
    //Printing values after the initial convolutional layer:
    //controller.print(firstLayer, 16384, "Initial layer: ");

    //layer1
    auto startLayer = start_time();
    resLayer1 = layer1(firstLayer);
    print_duration(startLayer, "Layer 1 took:");
    //controller.print(resLayer1, 16384, "Layer 1: ");
  
    //layer2

    resLayer2 = layer2(resLayer1);

    //controller.print(resLayer2, 8192, "Layer 2: ");

    //layer3

    resLayer3 = layer3(resLayer2);

    //controller.print(resLayer3, 4096, "Layer 3: ");

    //fianllayer

    finalRes = final_layer(resLayer3);


    if (verbose > 0) print_duration_yellow(start, "The evaluation of the whole circuit took: ");

    input_filename.clear();

}

void FHEController::generate_context(int log_ring, int log_scale, int log_primes, int digits_hks, int cts_levels,
                                     int stc_levels, int relu_degree, bool serialize) 
{
    CCParams<CryptoContextCKKSRNS> parameters;

    num_slots = 1 << 14;    //2^14 = 16384, Number of required slots.
    
    parameters.SetSecretKeyDist(SPARSE_TERNARY);    
    parameters.SetSecurityLevel(lbcrypto::HEStd_128_classic);   //Security Level
    parameters.SetNumLargeDigits(digits_hks);        
    parameters.SetRingDim(1 << log_ring);           //Ciphertext sparse packing to accelerate bootstrapping speed.
    parameters.SetBatchSize(num_slots);

    level_budget = vector<uint32_t>();            

    level_budget.push_back(cts_levels);           //Bootstrapping-related parameters
    level_budget.push_back(stc_levels);           //Bootstrapping-related parameters

    int dcrtBits = log_primes;                    
    int firstMod = log_scale;                     

    parameters.SetScalingModSize(dcrtBits);
    parameters.SetScalingTechnique(FLEXIBLEAUTO);   
    parameters.SetFirstModSize(firstMod);

    uint32_t approxBootstrapDepth = 4 + 4; //Expected multiplicative depth consumption during bootstrapping operation.

    uint32_t levelsUsedBeforeBootstrap = relu_degree + 11;   

    

    write_to_file("../keys/relu_degree.txt", to_string(relu_degree));
    write_to_file("../keys/level_budget.txt", to_string(level_budget[0]) + "," + to_string(level_budget[1]));
     
    circuit_depth = levelsUsedBeforeBootstrap +
                    FHECKKSRNS::GetBootstrapDepth(approxBootstrapDepth,level_budget, SPARSE_TERNARY);    

    cout<<"FHECKKSRNS::GetBootstrapDepth(level_budget, SPARSE_TERNARY) = " << FHECKKSRNS::GetBootstrapDepth(level_budget, SPARSE_TERNARY) <<endl;

    cout << endl << "Ciphertext multiplicative depth: " << circuit_depth << ", Supported multiplicative depth: "<< levelsUsedBeforeBootstrap - 2 << endl;

    parameters.SetMultiplicativeDepth(circuit_depth);

    context = GenCryptoContext(parameters);    

    cout << "Context built, generating keys..." << endl;

    context->Enable(PKE);          
    context->Enable(KEYSWITCH);    
    context->Enable(LEVELEDSHE);    
    context->Enable(ADVANCEDSHE);  
    context->Enable(FHE);           

    key_pair = context->KeyGen();       

    context->EvalMultKeyGen(key_pair.secretKey);   

    cout << "Context generation completed." << endl;


    ofstream multKeyFile("../keys/mult-keys.txt", ios::out | ios::binary);
    if (multKeyFile.is_open()) 
    {
        if (!context->SerializeEvalMultKey(multKeyFile, SerType::BINARY))    
        {
            cerr << "Failed to save multiplication keys." << std::endl;
            exit(1);
        }
        cout << "Multiplication keys saved successfully." << std::endl;
        multKeyFile.close();
    } else {
        cerr << "Error serializing EvalMult keys in \"" << "../keys/mult-keys.txt" << "\"" << endl;
        exit(1);
    }

    if (!Serial::SerializeToFile("../keys/crypto-context.txt", context, SerType::BINARY)) {
        cerr << "Failed to write the encryption context to crypto-context.txt." << endl;
    } else {
        cout << "Encryption context saved successfully." << std::endl;
    }

    if (!Serial::SerializeToFile("../keys/public-key.txt", key_pair.publicKey, SerType::BINARY)) {
        cerr << "Failed to write the public key to public-key.txt." << endl;
    } else {
        cout << "Public key saved successfully." << std::endl;
    }

    if (!Serial::SerializeToFile("../keys/secret-key.txt", key_pair.secretKey, SerType::BINARY)) {
        cerr << "Failed to write the secret key to secret-key.txt." << endl;
    } else {
        cout << "Secret key saved successfully." << std::endl;
    }

}

void FHEController::load_context(bool verbose) {
    context->ClearEvalMultKeys();                  
    context->ClearEvalAutomorphismKeys();

    CryptoContextFactory<lbcrypto::DCRTPoly>::ReleaseAllContexts();

    if (verbose) cout << "Starting to read the context..." << endl;

    if (!Serial::DeserializeFromFile("../keys/crypto-context.txt", context, SerType::BINARY)) 
    {
        cerr << "I cannot read serialized data from: " << "../" + parameters_folder + "/crypto-context.txt" << endl;
        exit(1);
    }

    PublicKey<DCRTPoly> clientPublicKey;
    if (!Serial::DeserializeFromFile("../keys/public-key.txt", clientPublicKey, SerType::BINARY)) {
        cerr << "I cannot read serialized data from public-key.txt" << endl;
        exit(1);
    }

    PrivateKey<DCRTPoly> serverSecretKey;
    if (!Serial::DeserializeFromFile("../keys/secret-key.txt", serverSecretKey, SerType::BINARY)) {
        cerr << "I cannot read serialized data from public-key.txt" << endl;
        exit(1);
    }

    key_pair.publicKey = clientPublicKey;
    key_pair.secretKey = serverSecretKey;

    std::ifstream multKeyIStream("../keys/mult-keys.txt", ios::in | ios::binary);
    if (!multKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "mult-keys.txt" << endl;
        exit(1);
    }
    if (!context->DeserializeEvalMultKey(multKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval mult key file" << endl;
        exit(1);
    }

    relu_degree = 3;

    level_budget[0] = read_from_file("../keys/level_budget.txt").at(0) - '0';
    level_budget[1] = read_from_file("../keys/level_budget.txt").at(2) - '0';

    if (verbose) cout << "CtoS: " << level_budget[0] << ", StoC: " << level_budget[1] << endl;

    uint32_t approxBootstrapDepth = 4 + 4;  

    uint32_t levelsUsedBeforeBootstrap = 3 + 11;

    circuit_depth = levelsUsedBeforeBootstrap + FHECKKSRNS::GetBootstrapDepth(approxBootstrapDepth,level_budget, SPARSE_TERNARY);

    if (verbose) cout << "Circuit depth: " << circuit_depth << ", available multiplications: " << levelsUsedBeforeBootstrap - 2 << endl;

    num_slots = 1 << 14;     //2^14 = 16384
}

void FHEController::generate_bootstrapping_keys(int bootstrap_slots) 
{
    context->EvalBootstrapSetup(level_budget, {0, 0}, bootstrap_slots);
    context->EvalBootstrapKeyGen(key_pair.secretKey, bootstrap_slots);
}

void FHEController::generate_rotation_keys(vector<int> rotations, bool serialize, std::string filename) {
    if (serialize && filename.size() == 0) {
        cout << "Filename cannot be empty when serializing rotation keys." << endl;
        return;
    }

    context->EvalRotateKeyGen(key_pair.secretKey, rotations);

    if (serialize) {
        ofstream rotationKeyFile("../keys/rot_" + filename, ios::out | ios::binary);
        if (rotationKeyFile.is_open()) {
            if (!context->SerializeEvalAutomorphismKey(rotationKeyFile, SerType::BINARY)) {
                cerr << "Error writing rotation keys" << std::endl;
                exit(1);
            }
            cout << "Rotation keys \"" << filename << "\" have been serialized" << std::endl;
        } else {
            cerr << "Error serializing Rotation keys" << "../keys/rot_" + filename << std::endl;
            exit(1);
        }
    }
}

//controller.generate_bootstrapping_and_rotation_keys({1, -1, 32, -32, -1024},16384,true,"rotations-layer1.bin");
void FHEController::generate_bootstrapping_and_rotation_keys(vector<int> rotations, int bootstrap_slots, bool serialize, const string& filename) {
    if (serialize && filename.empty()) {
        cout << "Filename cannot be empty when serializing bootstrapping and rotation keys." << endl;
        return;
    }

    generate_bootstrapping_keys(bootstrap_slots);
    generate_rotation_keys(rotations, serialize, filename);
}
//Reading bootstrapping and rotation keys.
void FHEController::load_bootstrapping_and_rotation_keys(const string& filename, int bootstrap_slots, bool verbose) {
    if (verbose) cout << endl << "Loading bootstrapping and rotations keys from " << filename << "..." << endl;

    auto start = start_time();

    context->EvalBootstrapSetup(level_budget, {0, 0}, bootstrap_slots);

    if (verbose)  cout << "(1/2) Bootstrapping precomputation completed!" << endl;

    ifstream rotKeyIStream("../keys/rot_" + filename, ios::in | ios::binary);
    if (!rotKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "../keys/rot_" << filename << std::endl;
        exit(1);
    }

    if (!context->DeserializeEvalAutomorphismKey(rotKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval rot key file" << std::endl;
        exit(1);
    }

    if (verbose) cout << "(2/2) Rotation keys have been read." << endl;

    if (verbose) print_duration(start, "Loading bootstrapping pre-computations + rotations");

    if (verbose) cout << endl;
}

void FHEController::load_rotation_keys(const string& filename, bool verbose) {
    if (verbose) cout << endl << "Loading rotations keys from " << filename << "..." << endl;

    auto start = start_time();

    ifstream rotKeyIStream("../keys/rot_" + filename, ios::in | ios::binary);
    if (!rotKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "../keys/rot_" << filename << std::endl;
        exit(1);
    }

    if (!context->DeserializeEvalAutomorphismKey(rotKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval rot key file" << std::endl;
        exit(1);
    }

    if (verbose) {
        cout << "(1/1) Rotation keys read!" << endl;
        print_duration(start, "Loading rotation keys");
        cout << endl;
    }
}

void FHEController::clear_bootstrapping_and_rotation_keys(int bootstrap_num_slots) {
    
    clear_rotation_keys();
}

void FHEController::clear_rotation_keys() {
    context->ClearEvalAutomorphismKeys();
}
//Cleared bootstrapping keys, rotation keys, and multiplication keys.
void FHEController::clear_context(int bootstrapping_key_slots) {
    if (bootstrapping_key_slots != 0)
        clear_bootstrapping_and_rotation_keys(bootstrapping_key_slots);
    else
        clear_rotation_keys();

    context->ClearEvalMultKeys();
}

/*
 * CKKS Encoding / Decoding / Encryption / Decryption Section
 */
//Encoding a vector of floating-point numbers
Ptxt FHEController::encode(const vector<double> &vec, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    Ptxt p = context->MakeCKKSPackedPlaintext(vec, 1, level, nullptr, plaintext_num_slots);
    p->SetLength(plaintext_num_slots);
    return p;
}
//Encode a single floating-point number.Encodes the input single floating-point value val into a vector-form plaintext.All elements of this vector are set to val. This is used for convolution kernels.
Ptxt FHEController::encode(double val, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    vector<double> vec;
    for (int i = 0; i < plaintext_num_slots; i++) {
        vec.push_back(val);
    }

    Ptxt p = context->MakeCKKSPackedPlaintext(vec, 1, level, nullptr, plaintext_num_slots);
    p->SetLength(plaintext_num_slots);
    return p;
}


Ctxt FHEController::encrypt(const vector<double> &vec, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    Ptxt p = encode(vec, level, plaintext_num_slots);

    return context->Encrypt(p, key_pair.publicKey);
}

Ctxt FHEController::encrypt_ptxt(const Ptxt& p) {
    return context->Encrypt(p, key_pair.publicKey);
}


Ptxt FHEController::decrypt(const Ctxt &c) {
    Ptxt p;
    context->Decrypt(key_pair.secretKey, c, &p);
    return p;
}

vector<double> FHEController::decrypt_tovector(const Ctxt &c, int slots) {
    if (slots == 0) {
        slots = num_slots;
    }

    Ptxt p;
    context->Decrypt(key_pair.secretKey, c, &p);
    p->SetSlots(slots);
    p->SetLength(slots);
    vector<double> vec = p->GetRealPackedValue();
    return vec;
}

/*
 * Homomorphic Operations Section
 */
Ctxt FHEController::add(const Ctxt &c1, const Ctxt &c2) {
    return context->EvalAdd(c1, c2);
}


Ctxt FHEController::mult(const Ctxt &c1, double d) {
    Ptxt p = encode(d, c1->GetLevel(), num_slots);
    return context->EvalMult(c1, p);
}

Ctxt FHEController::mult(const Ctxt &c, const Ptxt& p) {
    return context->EvalMult(c, p);
}

Ctxt FHEController::bootstrap(const Ctxt &c, bool timing) {
    if (static_cast<int>(c->GetLevel()) + 2 < circuit_depth && timing) {
        cout << "You are bootstrapping with remaining levels! You are at " << to_string(c->GetLevel()) << "/" << circuit_depth - 2 << endl;
    }


    auto start = start_time();

    Ctxt res = context->EvalBootstrap(c);

    if (timing) {
        print_duration(start, "Bootstrapping " + to_string(c->GetSlots()) + " slots");
    }

    cout<< "Bootstrapping completed. Remaining levels:"<<to_string(res->GetLevel())<<endl<<endl;

    return res;
}
//Bootstrapping with precision control.
Ctxt FHEController::bootstrap(const Ctxt &c, int precision, bool timing) {
    if (static_cast<int>(c->GetLevel()) + 2 < circuit_depth) {
        cout << "You are bootstrapping with remaining levels! You are at " << to_string(c->GetLevel()) << "/" << circuit_depth - 2 << endl;
    }

    auto start = start_time();

    Ctxt res = context->EvalBootstrap(c, 2, precision);

    if (timing) {
        print_duration(start, "Double Bootstrapping " + to_string(c->GetSlots()) + " slots");
    }

    return res;
}

Ctxt FHEController::silu(const Ctxt &c, double scale, bool timing) {
    auto start = start_time();
    //2.31748214368776e-19*x**5 - 0.00234401466164428*x**4 - 5.40294082621943e-17*x**3 + 0.152698548493255*x**2 + 0.500000000000001*x
    
    Ctxt res_1 = context->EvalMult(c, 0.5);                     
    Ctxt res_1fin = context->EvalMult(context->EvalMult(res_1, 1), 1);

    Ctxt res_2 = context->EvalMult(c, c);                       
    Ctxt res_2mid = context->EvalMult(res_2, 0.15269854849);      
    Ctxt res_2fin = context->EvalMult(res_2mid, 1);   

    Ctxt res_3 = context->EvalMult(c, -5.40294082621943e-17);              
    Ctxt res_3mid = context->EvalMult(res_2, res_3);              
    Ctxt res_3fin = context->EvalMult(res_3mid, 1);

    Ctxt res_4 = context->EvalMult(res_2, res_2);   
    Ctxt res_4mid = context->EvalMult(res_4, -0.00234401466164428);   

    Ctxt res_5 = context->EvalMult(c, 2.31748214368776e-19);  
    Ctxt res_5mid = context->EvalMult(res_4, res_5);   

    Ctxt res = add(res_5mid, add(res_4mid, add(res_3fin,add(res_2fin,res_1fin))));

    if (timing) {
        print_duration(start, "ReLU d = " + to_string(relu_degree) + " evaluation");
    }

    return res;
}

Ctxt FHEController::relu_wide(const Ctxt &c, double a, double b, int degree, double scale, bool timing) {
    auto start = start_time();

    /*
     * Max min
     */
    Ptxt result;
    context->Decrypt(key_pair.secretKey, c, &result);
    vector<double> v = result->GetRealPackedValue();

    cout << "min: " << *min_element(v.begin(), v.end()) << ", max: " << *max_element(v.begin(), v.end()) << endl;
    /*
     * Max min
     */

    Ctxt res = context->EvalChebyshevFunction([scale](double x) -> double { if (x < 0) return 0; else return (1 / scale) * x; }, c,
                                              a,
                                              b, degree);
    if (timing) {
        print_duration(start, "ReLU d = " + to_string(degree) + " evaluation");
    }

    return res;
}

Ctxt FHEController::rotsum1(const Ctxt &in) {
    Ctxt result = in->Clone();

    result = add(result, context->EvalRotate(in, 8192));
    result = add(result, context->EvalRotate(result, 4096));
    result = add(result, context->EvalRotate(result, 2048));
    result = add(result, context->EvalRotate(result, 64));
    result = add(result, context->EvalRotate(result, 32));
    result = add(result, context->EvalRotate(result, 16));


    return result;
}

Ctxt FHEController::rotsum2(const Ctxt &in) {
    Ctxt result = in->Clone();

    result = add(result, context->EvalRotate(in, 512));
    result = add(result, context->EvalRotate(result, 256));
    result = add(result, context->EvalRotate(result, 128));
    result = add(result, context->EvalRotate(result, 4));
    result = add(result, context->EvalRotate(result, 2));
    result = add(result, context->EvalRotate(result, 1));


    return result;
}

void print_moduli_chain(const DCRTPoly& poly){
    int num_primes = poly.GetNumOfElements();
    double total_bit_len = 0.0;
    for (int i = 0; i < num_primes; i++) {
        auto qi = poly.GetParams()->GetParams()[i]->GetModulus();
        std::cout << "q_" << i << ": " 
                    << qi
                    << ",  log q_" << i <<": " << log(qi.ConvertToDouble()) / log(2)
                    << std::endl;
        total_bit_len += log(qi.ConvertToDouble()) / log(2);
    }   
    std::cout << "Total bit length: " << total_bit_len << std::endl;
}

Ctxt FHEController::convbn_initial(const Ctxt &in, double scale, bool timing) {
    //The ciphertext has been spatially densely packed into in, with rotation key indices: {4, -4, 512, -512}.
    auto start = start_time();

    vector<Ctxt> c_rotations;
    
    auto digits = context->EvalFastRotationPrecompute(in);

    //Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-516, -512, -508, -4, 0, 4, 508, 512, 516}
    // Rotate 4
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits);
    //  Rotate -4
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits);
    // Rotate 512
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 512, context->GetCyclotomicOrder(), digits);
    // Rotate -512
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -512, context->GetCyclotomicOrder(), digits);
    // Rotate 508
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), 512 ); 
    // Rotate -508
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), -512 ); 
    //Rotate 516
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), 512 );  
    //Rotate -516
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), -512 );  
    //{-516,-512,-508,-4,0,4,508,512,516} （-6,-5,-4,-1,0,1,4,5,6）
    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
    // The rotations of the input ciphertext in have been generated and stored in c_rotations.


    
    Ptxt bias = encode(read_values_from_file("../weights/conv0_bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;
    
    for (int j = 0; j < 16; j++) {
        vector<Ctxt> k_rows;

        for (int k = 0; k < 9; k++) {
            vector<double> values = read_values_from_file("../weights/conv0-ch" +
                                                          to_string(j) + "-k" + to_string(k+1) + ".txt", scale);
            Ptxt encoded = encode(values, in->GetLevel(), 16384);
            k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
        }

        Ctxt sum = context->EvalAddMany(k_rows); //Sum the nine product results to obtain the convolution result for the current channel.

        Ctxt res = sum->Clone();

        res = add(res, context->EvalRotate(sum, 1));
        res = add(res, context->EvalRotate(sum, 128));

        Ptxt mean = encode(read_values_from_file("../weights/conv0_mean" + to_string(j+1) + ".txt", scale), in->GetLevel(), 16384);
        res = context->EvalAdd(res,mean);


        vector<double> gamma = read_values_from_file("../weights/conv0_gamma" + to_string(j+1)+ ".txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        res = mult(res,encoded);
 
        switch (j)
        {
        case 0:
            finalsum = res->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level: " << finalsum->GetLevel() << endl;


    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level: " << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn(const Ctxt &in, int layer, int n, double scale, bool timing) {
    auto start = start_time();

    vector<Ctxt> c_rotations;

    auto digits = context->EvalFastRotationPrecompute(in);

    //Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-516, -512, -508, -4, 0, 4, 508, 512, 516}
    // Rotate 4
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits);
    // Rotate -4
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits);
    // Rotate 512
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 512, context->GetCyclotomicOrder(), digits);
    // Rotate -512
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -512, context->GetCyclotomicOrder(), digits);
    // Rotate 508
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), 512 ); 
    // Rotate -508
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), -512 ); 
    //Rotate 516
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), 512 );  
    //Rotate -516
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), -512 );  

    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
    // The rotations of the input ciphertext in have been generated and stored in c_rotations.
	

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-conv" + to_string(n) + "bn" + to_string(n) + "-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;

    for (int j = 0; j < 16; j++) {
        vector<Ctxt> k_rows;
        //                                                                                1,                          1,                    1
        for (int k = 0; k < 9; k++) {
            vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-conv" + to_string(n) + "bn" + to_string(n) + "-ch" +
                                                      to_string(j) + "-k" + to_string(k+1) + ".txt", 1);
            Ptxt encoded = encode(values, in->GetLevel(), 16384);
            k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
        }

        Ctxt sum = context->EvalAddMany(k_rows); 

        Ctxt res = sum->Clone();
		

		res = add(res, context->EvalRotate(sum, 256));
        res = add(res, context->EvalRotate(res, 128));
        res = add(res, context->EvalRotate(res, 2));
        res = add(res, context->EvalRotate(res, 1));

        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-conv" + to_string(n) + "bn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-mean.txt", 1), in->GetLevel(), 16384);
        res = context->EvalAdd(res,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-conv" + to_string(n) + "bn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        res = mult(res,encoded);

        switch (j)
        {
        case 0:
            finalsum = res->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level: " << finalsum->GetLevel() << endl;


    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level: " << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn2(const Ctxt &in, int layer, int n, double scale, bool timing) {
    auto start = start_time();

    vector<Ctxt> c_rotations;

    auto digits = context->EvalFastRotationPrecompute(in);

    //The rotation pattern here differs from convbn. convbn uses 4x4 blocks, while here 8x8 blocks are used. 32*16*16. 128/16 = 8.
	//Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-1032, -1024, -1016, -8, 0, 8, 1016, 1024, 1032}
    // Rotate 8
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits);
    // Rotate  -8
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits);
    // Rotate  1024
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 1024, context->GetCyclotomicOrder(), digits);
    // Rotate  -1024
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -1024, context->GetCyclotomicOrder(), digits);
    // Rotate  1016
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits), 1024 ); 
    // Rotate  -1016
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits), -1024 ); 
    //Rotate  1032
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits), 1024 );  
    //Rotate  -1032
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits), -1024 );  

    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
	// The rotations of the input ciphertext in have been generated and stored in c_rotations.
	

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;

    vector<Ctxt> k_rows;


    for (int k = 0; k < 9; k++) {
        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-depth-k" + to_string(k+1) + ".txt", scale);
        Ptxt encoded = encode(values, in->GetLevel(), 16384);
        k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
    }

    Ctxt sum = context->EvalAddMany(k_rows);  

    for (int j = 0; j < 32; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-point-ch" +
                                                          to_string(j) + ".txt", scale);
        Ctxt res = context->EvalMult(sum, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();


        tmp = add(tmp, context->EvalRotate(res, 512));
        tmp = add(tmp, context->EvalRotate(tmp, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 4));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));

        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-mean.txt", scale), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level: " << finalsum->GetLevel() << endl;


    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level: " << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn3(const Ctxt &in, int layer, int n, double scale, bool timing) {
    auto start = start_time();

    vector<Ctxt> c_rotations;

    auto digits = context->EvalFastRotationPrecompute(in);

    //convbv2 uses 8x8 blocks. 32*16*16. 128/8 = 16.convbn3 packs four 8x8 blocks into one location's information. 64*8*8. 128/16 = 8.
    //Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-2064, -2048, -2032, -16, 0, 16, 2032, 2048, 2064}
    // Rotate 8
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 16, context->GetCyclotomicOrder(), digits);
    // Rotate -8
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -16, context->GetCyclotomicOrder(), digits);
    // Rotate 1024
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 2048, context->GetCyclotomicOrder(), digits);
    // Rotate -1024
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -2048, context->GetCyclotomicOrder(), digits);
    // Rotate 1016
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -16, context->GetCyclotomicOrder(), digits), 2048 ); 
    // Rotate -1016
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 16, context->GetCyclotomicOrder(), digits), -2048 ); 
    //Rotate 1032
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 16, context->GetCyclotomicOrder(), digits), 2048 );  
    //Rotate -1032
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -16, context->GetCyclotomicOrder(), digits), -2048 );  

    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
    //The rotations of the input ciphertext in have been generated and stored in c_rotations.
	

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;

    vector<Ctxt> k_rows;


    for (int k = 0; k < 9; k++) {
        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-depth-k" + to_string(k+1) + ".txt", 1);
        Ptxt encoded = encode(values, in->GetLevel(), 16384);
        k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
    }

    Ctxt sum = context->EvalAddMany(k_rows);  

    for (int j = 0; j < 64; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-point-ch" +
                                                          to_string(j) + ".txt", 1);
        Ctxt res = context->EvalMult(sum, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();


		tmp = add(tmp, context->EvalRotate(res, 512));
        tmp = add(tmp, context->EvalRotate(tmp, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 4));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));


        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-mean.txt", 1), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);

        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -6));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -7));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -134));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -135));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -262));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -263));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -390));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -391));
            break;
        case 32:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 33:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 34:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 35:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 36:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 37:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 38:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -518));
            break;
        case 39:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -519));
            break;
        case 40:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 41:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        case 42:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -642));
            break;
        case 43:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -643));
            break;
        case 44:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -644));
            break;
        case 45:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -645));
            break;
        case 46:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -646));
            break;
        case 47:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -647));
            break;
        case 48:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -768));
            break;
        case 49:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -769));
            break;
        case 50:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -770));
            break;
        case 51:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -771));
            break;
        case 52:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -772));
            break;
        case 53:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -773));
            break;
        case 54:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -774));
            break;
        case 55:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -775));
            break;
        case 56:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -896));
            break;
        case 57:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -897));
            break;
        case 58:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -898));
            break;
        case 59:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -899));
            break;
        case 60:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -900));
            break;
        case 61:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -901));
            break;
        case 62:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -902));
            break;
        case 63:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -903));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level:" << finalsum->GetLevel() << endl;

    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level:" << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "convbn3：");
    }


    return finalsum;
}


Ctxt FHEController::convbn1632sx(const Ctxt &in, int layer, int n, double scale, bool timing) {
    auto start = start_time();

    vector<Ctxt> c_rotations;

    auto digits = context->EvalFastRotationPrecompute(in);

	// 16 channels expanded to 32 channels, 16*32*32 -> 32*16*16. 4x4 blocks changed to 8x8 blocks.
	// Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-516, -512, -508, -4, 0, 4, 508, 512, 516}
	// Rotate 4
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits);
    // Rotate -4
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits);
    // Rotate 512
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 512, context->GetCyclotomicOrder(), digits);
    // Rotate -512
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -512, context->GetCyclotomicOrder(), digits);
    // Rotate 508
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), 512 ); 
    // Rotate -508
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), -512 ); 
    //Rotate 516
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 4, context->GetCyclotomicOrder(), digits), 512 );  
    //Rotate -516
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -4, context->GetCyclotomicOrder(), digits), -512 );  

    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
    //The rotations of the input ciphertext in have been generated and stored in c_rotations.
	

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;

    vector<Ctxt> k_rows;


    for (int k = 0; k < 9; k++) {
        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-depth-k" + to_string(k+1) + ".txt", scale);
        Ptxt encoded = encode(values, in->GetLevel(), 16384);
        k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
    }

    Ctxt sum = context->EvalAddMany(k_rows);  

    for (int j = 0; j < 32; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-point-ch" +
                                                          to_string(j) + ".txt", scale);
        Ctxt res = context->EvalMult(sum, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();

		tmp = add(tmp, context->EvalRotate(res, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));

        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-mean.txt", scale), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level:" << finalsum->GetLevel() << endl;


    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level:" << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn1632dx(const Ctxt &in, int layer, int n, double scale, bool timing) {
	// Downsampling branch: input 16*32*32, output 32*16*16, using 32 channels of 1x1 convolutions with stride=2.
	// Since it's a 1x1 convolution kernel, 8 rotated ciphertexts are not required.
    auto start = start_time();
	

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-shortcut-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;


    for (int j = 0; j < 32; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-point-ch" +
                                                          to_string(j) + ".txt", scale);
        Ctxt res = context->EvalMult(in, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();


		tmp = add(tmp, context->EvalRotate(res, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));

        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-ch" +
                                                      to_string(j) +"-mean.txt", scale), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level: " << finalsum->GetLevel() << endl;

    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level:" << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn3264sx(const Ctxt &in, int layer, int n, double scale, bool timing) {
    auto start = start_time();

    vector<Ctxt> c_rotations;

    auto digits = context->EvalFastRotationPrecompute(in);

	// Input here is 32*16*16. Output is 64*8*8. 8x8 blocks, where four blocks (top, bottom, left, right) store the 64-channel data for one position, filling the entire 8x8 block.
	// The rotation pattern here differs from convbn. convbn uses 4x4 blocks, while here 8x8 blocks are used. 32*16*16. 128/16 = 8.
	// Order: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right. {-1032, -1024, -1016, -8, 0, 8, 1016, 1024, 1032}
	// Rotate 8
    Ctxt rotatedCiphertext_tmp1 = context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits);
    // Rotate -8
    Ctxt rotatedCiphertext_tmp2 = context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits);
    // Rotate 1024
    Ctxt rotatedCiphertext_tmp3 = context->EvalFastRotation(in, 1024, context->GetCyclotomicOrder(), digits);
    // Rotate -1024
    Ctxt rotatedCiphertext_tmp4 = context->EvalFastRotation(in, -1024, context->GetCyclotomicOrder(), digits);
    // Rotate 1016
    Ctxt rotatedCiphertext_tmp5 = context->EvalRotate(context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits), 1024 ); 
    // Rotate -1016
    Ctxt rotatedCiphertext_tmp6 = context->EvalRotate(context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits), -1024 ); 
    //Rotate 1032
    Ctxt rotatedCiphertext_tmp7 = context->EvalRotate(context->EvalFastRotation(in, 8, context->GetCyclotomicOrder(), digits), 1024 );  
    //Rotate -1032
    Ctxt rotatedCiphertext_tmp8 = context->EvalRotate(context->EvalFastRotation(in, -8, context->GetCyclotomicOrder(), digits), -1024 ); 

    c_rotations.push_back(rotatedCiphertext_tmp8);
    c_rotations.push_back(rotatedCiphertext_tmp4);
    c_rotations.push_back(rotatedCiphertext_tmp6);
    c_rotations.push_back(rotatedCiphertext_tmp2);
    c_rotations.push_back(in);
    c_rotations.push_back(rotatedCiphertext_tmp1);
    c_rotations.push_back(rotatedCiphertext_tmp5);
    c_rotations.push_back(rotatedCiphertext_tmp3);
    c_rotations.push_back(rotatedCiphertext_tmp7);
	// The rotations of the input ciphertext in have been generated and stored in c_rotations.
	


    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;

    vector<Ctxt> k_rows;


    for (int k = 0; k < 9; k++) {
        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-depth-k" + to_string(k+1) + ".txt", 1);
        Ptxt encoded = encode(values, in->GetLevel(), 16384);
        k_rows.push_back(context->EvalMult(c_rotations[k], encoded));
    }

    Ctxt sum = context->EvalAddMany(k_rows);   



    for (int j = 0; j < 64; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-point-ch" +
                                                          to_string(j) + ".txt", 1);
        Ctxt res = context->EvalMult(sum, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();


		tmp = add(tmp, context->EvalRotate(res, 512));
        tmp = add(tmp, context->EvalRotate(tmp, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 4));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));


        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-mean.txt", 1), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -6));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -7));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -134));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -135));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -262));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -263));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -390));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -391));
            break;
        case 32:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 33:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 34:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 35:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 36:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 37:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 38:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -518));
            break;
        case 39:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -519));
            break;
        case 40:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 41:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        case 42:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -642));
            break;
        case 43:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -643));
            break;
        case 44:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -644));
            break;
        case 45:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -645));
            break;
        case 46:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -646));
            break;
        case 47:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -647));
            break;
        case 48:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -768));
            break;
        case 49:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -769));
            break;
        case 50:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -770));
            break;
        case 51:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -771));
            break;
        case 52:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -772));
            break;
        case 53:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -773));
            break;
        case 54:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -774));
            break;
        case 55:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -775));
            break;
        case 56:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -896));
            break;
        case 57:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -897));
            break;
        case 58:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -898));
            break;
        case 59:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -899));
            break;
        case 60:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -900));
            break;
        case 61:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -901));
            break;
        case 62:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -902));
            break;
        case 63:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -903));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level:" << finalsum->GetLevel() << endl;


    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level:" << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt FHEController::convbn3264dx(const Ctxt &in, int layer, int n, double scale, bool timing) {
	// Downsampling branch: input 32*16*16, output 64*8*8, using 64 channels of 1x1 convolutions with stride=2.
	// Since it's a 1x1 convolution kernel, 8 rotated ciphertexts are not required.
    auto start = start_time();
  

    Ptxt bias = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) +"-shortcut-bias.txt", scale), in->GetLevel(), 16384);

    Ctxt finalsum;


    for (int j = 0; j < 64; j++) {

        vector<double> values = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-point-ch" +
                                                          to_string(j) + ".txt", 1);
        Ctxt res = context->EvalMult(in, encode(values, in->GetLevel(), 16384));
        Ctxt tmp = res->Clone();


		tmp = add(tmp, context->EvalRotate(res, 512));
        tmp = add(tmp, context->EvalRotate(tmp, 256));
        tmp = add(tmp, context->EvalRotate(tmp, 128));
        tmp = add(tmp, context->EvalRotate(tmp, 4));
        tmp = add(tmp, context->EvalRotate(tmp, 2));
        tmp = add(tmp, context->EvalRotate(tmp, 1));

        Ptxt mean = encode(read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-ch" +
                                                      to_string(j) +"-mean.txt", 1), in->GetLevel(), 16384);
        tmp = context->EvalAdd(tmp,mean);


        vector<double> gamma = read_values_from_file("../weights/layer" + to_string(layer) + "-convbn" + to_string(n) + "-shortcut-ch" +
                                                      to_string(j) +"-gamma.txt", scale);
        Ptxt encoded = encode(gamma, in->GetLevel(), 16384);
        tmp = mult(tmp,encoded);

        switch (j)
        {
        case 0:
            finalsum = tmp->Clone();
            break;
        case 1:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -1));
            break;
        case 2:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -2));
            break;
        case 3:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -3));
            break;
        case 4:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -4));
            break;
        case 5:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -5));
            break;
        case 6:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -6));
            break;
        case 7:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -7));
            break;
        case 8:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -128));
            break;
        case 9:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -129));
            break;
        case 10:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -130));
            break;
        case 11:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -131));
            break;
        case 12:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -132));
            break;
        case 13:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -133));
            break;
        case 14:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -134));
            break;
        case 15:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -135));
            break;
        case 16:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -256));
            break;
        case 17:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -257));
            break;
        case 18:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -258));
            break;
        case 19:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -259));
            break;
        case 20:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -260));
            break;
        case 21:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -261));
            break;
        case 22:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -262));
            break;
        case 23:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -263));
            break;
        case 24:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -384));
            break;
        case 25:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -385));
            break;
        case 26:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -386));
            break;
        case 27:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -387));
            break;
        case 28:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -388));
            break;
        case 29:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -389));
            break;
        case 30:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -390));
            break;
        case 31:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -391));
            break;
        case 32:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -512));
            break;
        case 33:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -513));
            break;
        case 34:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -514));
            break;
        case 35:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -515));
            break;
        case 36:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -516));
            break;
        case 37:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -517));
            break;
        case 38:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -518));
            break;
        case 39:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -519));
            break;
        case 40:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -640));
            break;
        case 41:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -641));
            break;
        case 42:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -642));
            break;
        case 43:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -643));
            break;
        case 44:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -644));
            break;
        case 45:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -645));
            break;
        case 46:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -646));
            break;
        case 47:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -647));
            break;
        case 48:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -768));
            break;
        case 49:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -769));
            break;
        case 50:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -770));
            break;
        case 51:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -771));
            break;
        case 52:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -772));
            break;
        case 53:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -773));
            break;
        case 54:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -774));
            break;
        case 55:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -775));
            break;
        case 56:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -896));
            break;
        case 57:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -897));
            break;
        case 58:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -898));
            break;
        case 59:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -899));
            break;
        case 60:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -900));
            break;
        case 61:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -901));
            break;
        case 62:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -902));
            break;
        case 63:
            finalsum = context->EvalAdd(finalsum, context->EvalRotate(res, -903));
            break;
        default:
            break;
        }

    }
    cout << "After convolution, ciphertext level:" << finalsum->GetLevel() << endl;

    finalsum = context->EvalAdd(finalsum, bias);

    cout << "After BN, ciphertext level:" << finalsum->GetLevel() << endl;
    if (timing) {
        print_duration(start, "Initial layer");
    }


    return finalsum;
}

Ctxt initial_layer(const Ctxt& in) {
    double scale = 1;   

    cout << "Before starting the initial layer, ciphertext level: " << in->GetLevel() << endl;      
    Ctxt res = controller.convbn_initial(in, scale, verbose > 1);
 
    cout << "Before starting the SiLU activation, ciphertext level: " << res->GetLevel() << endl;         
    res = controller.silu(res, scale, verbose > 1);                     
    cout << "After starting the SiLU activation, ciphertext level: " << res->GetLevel() << endl;         

    return res;
}

Ctxt layer1(const Ctxt& in) {
    bool timing = 1;
    double scale = 1;

    //block 1
    if (verbose > 1) cout << "---Start: Layer1 - Block 1---" << endl;  
    auto start = start_time();
    
    vector<double> clear_result_layer1in = controller.decrypt_tovector(in, 0);
    auto maxIt_layer1in = std::max_element(clear_result_layer1in.begin(), clear_result_layer1in.end());
    auto minIt_layer1in = std::min_element(clear_result_layer1in.begin(), clear_result_layer1in.end());
    std::cout << "Maximum value: " << *maxIt_layer1in << std::endl;
    std::cout << "Minimum value: " << *minIt_layer1in << std::endl;

    Ctxt res1;
    res1 = controller.convbn(in, 1, 1, scale, timing);    
    cout << "After starting layer1 conv1, ciphertext level:" << res1->GetLevel() << endl;         

    res1 = controller.bootstrap(res1, timing);                
    cout << "After starting bootstrap1, ciphertext level:" << res1->GetLevel() << endl;        
    
    res1 = controller.silu(res1, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res1->GetLevel() << endl;          

    vector<double> clear_result = controller.decrypt_tovector(res1, 0);
    save_vector_to_txt(clear_result, "output_layer1_silu1_out.txt");
    auto maxIt = std::max_element(clear_result.begin(), clear_result.end());
    auto minIt = std::min_element(clear_result.begin(), clear_result.end());
    std::cout << "Maximum value: " << *maxIt << std::endl;
    std::cout << "Minimum value: " << *minIt << std::endl;
    
    res1 = controller.convbn(res1, 1, 2, scale, timing);    
    cout << "After starting layer1 conv2, ciphertext level:" << res1->GetLevel() << endl;           

    vector<double> clear_result_convbn2 = controller.decrypt_tovector(res1, 0);
    save_vector_to_txt(clear_result_convbn2, "output_layer1_convbn2_out.txt");
    auto maxIt_convbn2 = std::max_element(clear_result_convbn2.begin(), clear_result_convbn2.end());
    auto minIt_convbn2 = std::min_element(clear_result_convbn2.begin(), clear_result_convbn2.end());
    std::cout << "Maximum value: " << *maxIt_convbn2 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbn2 << std::endl;

    res1 = controller.add(res1, in);     

    vector<double> clear_result_add = controller.decrypt_tovector(res1, 0);
    auto maxIt_add  = std::max_element(clear_result_add.begin(), clear_result_add.end());
    auto minIt_add  = std::min_element(clear_result_add.begin(), clear_result_add.end());
    std::cout << "Maximum value: " << *maxIt_add << std::endl;
    std::cout << "Minimum value: " << *minIt_add << std::endl;


    std::ofstream outFile2("output_add.txt");
    for (const auto& value : clear_result_add) {
        outFile2 << value << std::endl; 
    }

    outFile2.close();

    res1 = controller.silu(res1, scale, timing);
    cout << "After starting silu2, ciphertext level: " << res1->GetLevel() << endl;      
    
    vector<double> clear_result_silu2 = controller.decrypt_tovector(res1, 0);
    save_vector_to_txt(clear_result_silu2, "output_layer1_silu2_out.txt");
    auto maxIt_silu2 = std::max_element(clear_result_silu2.begin(), clear_result_silu2.end());
    auto minIt_silu2 = std::min_element(clear_result_silu2.begin(), clear_result_silu2.end());
    std::cout << "Maximum value: " << *maxIt_silu2 << std::endl;
    std::cout << "Minimum value: " << *minIt_silu2 << std::endl;

    res1 = controller.bootstrap(res1, timing);
    cout << "After starting bootstrap2, ciphertext level:" << res1->GetLevel() << endl;        

    vector<double> clear_result_bootstrap2 = controller.decrypt_tovector(res1, 0);
    save_vector_to_txt(clear_result_bootstrap2, "output_layer1_bootstrap2_out.txt");
    auto maxIt_bootstrap2 = std::max_element(clear_result_bootstrap2.begin(), clear_result_bootstrap2.end());
    auto minIt_bootstrap2 = std::min_element(clear_result_bootstrap2.begin(), clear_result_bootstrap2.end());
    std::cout << "Maximum value: " << *maxIt_bootstrap2 << std::endl;
    std::cout << "Minimum value: " << *minIt_bootstrap2 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer1 - Block 1---" << endl;

    if (verbose > 1) cout << "---Start: Layer1 - Block 2---" << endl;
    start = start_time();
    Ctxt res2;

    res2 = controller.convbn(res1, 2, 1, scale, timing);
    cout << "After starting layer1_conv3, ciphertext level: " << res2->GetLevel() << endl;            
    vector<double> clear_result_convbn3 = controller.decrypt_tovector(res2, 0);
    save_vector_to_txt(clear_result_convbn3, "output_layer1_convbn3_out.txt");
    auto maxIt_convbn3 = std::max_element(clear_result_convbn3.begin(), clear_result_convbn3.end());
    auto minIt_convbn3 = std::min_element(clear_result_convbn3.begin(), clear_result_convbn3.end());
    std::cout << "Maximum value: " << *maxIt_convbn3 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbn3 << std::endl;

    
    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level: " << res2->GetLevel() << endl;                    
    vector<double> clear_result_silu3 = controller.decrypt_tovector(res2, 0);
    save_vector_to_txt(clear_result_silu3, "output_layer1_silu3_out.txt");
    auto maxIt_silu3 = std::max_element(clear_result_silu3.begin(), clear_result_silu3.end());
    auto minIt_silu3 = std::min_element(clear_result_silu3.begin(), clear_result_silu3.end());
    std::cout << "Maximum value: " << *maxIt_silu3 << std::endl;
    std::cout << "Minimum value: " << *minIt_silu3 << std::endl;


    res2 = controller.convbn(res2, 2, 2, scale, timing);
    cout << "After starting layer1_conv4, ciphertext level: " << res2->GetLevel() << endl;           
    vector<double> clear_result_convbn4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_convbn4 = std::max_element(clear_result_convbn4.begin(), clear_result_convbn4.end());
    auto minIt_convbn4 = std::min_element(clear_result_convbn4.begin(), clear_result_convbn4.end());
    std::cout << "Maximum value: " << *maxIt_convbn4 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbn4 << std::endl;
    
    res2 = controller.bootstrap(res2, timing);
    cout << "After bootstrapping, ciphertext level:" << res2->GetLevel() <<", then starting conv4."<< endl;   
    vector<double> clear_result_bootstrap3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_bootstrap3 = std::max_element(clear_result_bootstrap3.begin(), clear_result_bootstrap3.end());
    auto minIt_bootstrap3 = std::min_element(clear_result_bootstrap3.begin(), clear_result_bootstrap3.end());
    std::cout << "Maximum value: " << *maxIt_bootstrap3 << std::endl;
    std::cout << "Minimum value: " << *minIt_bootstrap3 << std::endl;
    
    res2 = controller.add(res2, res1);                                         

    vector<double> clear_result_add3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_add3 = std::max_element(clear_result_add3.begin(), clear_result_add3.end());
    auto minIt_add3 = std::min_element(clear_result_add3.begin(), clear_result_add3.end());
    std::cout << "Maximum value: " << *maxIt_add3 << std::endl;
    std::cout << "Minimum value: " << *minIt_add3 << std::endl;


    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level: " << res2->GetLevel() << endl;               
    vector<double> clear_result_silu4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_silu4 = std::max_element(clear_result_silu4.begin(), clear_result_silu4.end());
    auto minIt_silu4 = std::min_element(clear_result_silu4.begin(), clear_result_silu4.end());
    std::cout << "Maximum value: " << *maxIt_silu4 << std::endl;
    std::cout << "Minimum value: " << *minIt_silu4 << std::endl;
    
    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer1 - Block 2---" << endl;
    

    if (verbose > 1) cout << "---Start: Layer1 - Block 3---" << endl;
    start = start_time();
    Ctxt res3;

    res3 = controller.convbn(res2, 3, 1, scale, timing);
    cout << "After starting layer1_conv5, ciphertext level:" << res3->GetLevel() << endl;       
    vector<double> clear_result_convbn5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_convbn5 = std::max_element(clear_result_convbn5.begin(), clear_result_convbn5.end());
    auto minIt_convbn5 = std::min_element(clear_result_convbn5.begin(), clear_result_convbn5.end());
    std::cout << "Maximum value: " << *maxIt_convbn5 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbn5 << std::endl;
    
    res3 = controller.silu(res3, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;               
    vector<double> clear_result_silu5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_silu5 = std::max_element(clear_result_silu5.begin(), clear_result_silu5.end());
    auto minIt_silu5 = std::min_element(clear_result_silu5.begin(), clear_result_silu5.end());
    std::cout << "Maximum value: " << *maxIt_silu5 << std::endl;
    std::cout << "Minimum value: " << *minIt_silu5 << std::endl;

    res3 = controller.bootstrap(res3, timing);
    cout << "After bootstrapping, ciphertext level: " << res3->GetLevel() <<", then starting conv5."<< endl;   
    vector<double> clear_result_bootstrap4 = controller.decrypt_tovector(res3, 0);
    auto maxIt_bootstrap4 = std::max_element(clear_result_bootstrap4.begin(), clear_result_bootstrap4.end());
    auto minIt_bootstrap4 = std::min_element(clear_result_bootstrap4.begin(), clear_result_bootstrap4.end());
    std::cout << "Maximum value: " << *maxIt_bootstrap4 << std::endl;
    std::cout << "Minimum value: " << *minIt_bootstrap4 << std::endl;

    res3 = controller.convbn(res3, 3, 2, scale, timing);
    cout << "After starting layer1_conv6, ciphertext level:" << res3->GetLevel() << endl;            
    vector<double> clear_result_convbn6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_convbn6 = std::max_element(clear_result_convbn6.begin(), clear_result_convbn6.end());
    auto minIt_convbn6 = std::min_element(clear_result_convbn6.begin(), clear_result_convbn6.end());
    std::cout << "Maximum value: " << *maxIt_convbn6 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbn6 << std::endl;
    
    res3 = controller.add(controller.mult(res3,1), res2);                             

    vector<double> clear_result_add4 = controller.decrypt_tovector(res3, 0);
    auto maxIt_add4 = std::max_element(clear_result_add4.begin(), clear_result_add4.end());
    auto minIt_add4 = std::min_element(clear_result_add4.begin(), clear_result_add4.end());
    std::cout << "Maximum value: " << *maxIt_add4 << std::endl;
    std::cout << "Minimum value: " << *minIt_add4 << std::endl;
    
    res3 = controller.silu(res3, scale, timing);                            
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;              
    vector<double> clear_result_silu6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_silu6 = std::max_element(clear_result_silu6.begin(), clear_result_silu6.end());
    auto minIt_silu6 = std::min_element(clear_result_silu6.begin(), clear_result_silu6.end());
    std::cout << "Maximum value: " << *maxIt_silu6 << std::endl;
    std::cout << "Minimum value: " << *minIt_silu6 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer1 - Block 3---" << endl;

    

    return res3;
}

Ctxt layer2(const Ctxt& in) {
    //sx is the main path, dx is the branch path.
    double scale = 0.1;  

    bool timing = verbose > 1;

    if (verbose > 1) cout << "---Start: Layer2 - Block 1---" << endl;
    auto start = start_time();
    Ctxt boot_in = controller.bootstrap(in, timing);
    cout << "After bootstrapping, ciphertext level:" << boot_in->GetLevel() <<", then starting the downsampling convolution conv1."<< endl;    
    vector<double> clear_result_boot1 = controller.decrypt_tovector(boot_in, 0);
    auto maxIt_boot1 = std::max_element(clear_result_boot1.begin(), clear_result_boot1.end());
    auto minIt_boot1 = std::min_element(clear_result_boot1.begin(), clear_result_boot1.end());
    std::cout << "Maximum value: " << *maxIt_boot1 << std::endl;
    std::cout << "Minimum value: " << *minIt_boot1 << std::endl;


    controller.clear_bootstrapping_and_rotation_keys(16384);
    controller.load_rotation_keys("rotations-layer2-downsample.bin", timing);    

    Ctxt res1sx = controller.convbn1632sx(boot_in, 4, 1, scale, timing);     
    Ctxt res1dx = controller.convbn1632dx(boot_in, 4, 1, scale, timing);     
    cout << "After starting the layer2_conv1 downsampling convolution, main path ciphertext level: " << res1sx->GetLevel() << endl;         
    cout << "After starting the layer2_conv1 downsampling convolution, branch path ciphertext level: " << res1dx->GetLevel() << endl;            
    vector<double> clear_result_convbnsx1 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_convbnsx1 = std::max_element(clear_result_convbnsx1.begin(), clear_result_convbnsx1.end());
    auto minIt_convbnsx1 = std::min_element(clear_result_convbnsx1.begin(), clear_result_convbnsx1.end());
    std::cout << "Maximum value: " << *maxIt_convbnsx1 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbnsx1 << std::endl;
    vector<double> clear_result_convbndx1 = controller.decrypt_tovector(res1dx, 0);
    auto maxIt_convbndx1 = std::max_element(clear_result_convbndx1.begin(), clear_result_convbndx1.end());
    auto minIt_convbndx1 = std::min_element(clear_result_convbndx1.begin(), clear_result_convbndx1.end());
    std::cout << "Maximum value: " << *maxIt_convbndx1 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbndx1 << std::endl;

    controller.clear_rotation_keys();

    controller.load_bootstrapping_and_rotation_keys("rotations-layer2.bin", 16384, verbose > 1);

    res1sx = controller.silu(res1sx, scale, timing);                                          
    cout << "After starting silu1, ciphertext level:" << res1sx->GetLevel() << endl;                                 
    vector<double> clear_result_layer2silu1 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2silu1 = std::max_element(clear_result_layer2silu1.begin(), clear_result_layer2silu1.end());
    auto minIt_layer2silu1 = std::min_element(clear_result_layer2silu1.begin(), clear_result_layer2silu1.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu1 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu1 << std::endl;

    scale = 1;   
    res1sx = controller.convbn2(res1sx, 4, 2, scale, timing);                                       
    cout << "After starting layer2_conv2, main path ciphertext level: " << res1sx->GetLevel() << endl;                
    vector<double> clear_result_layer2conv2 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2conv2 = std::max_element(clear_result_layer2conv2.begin(), clear_result_layer2conv2.end());
    auto minIt_layer2conv2 = std::min_element(clear_result_layer2conv2.begin(), clear_result_layer2conv2.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv2 << std::endl;

    res1sx = controller.bootstrap(res1sx, timing);
    cout << "After bootstrapping, ciphertext level:" << res1sx->GetLevel() <<", then starting conv2."<< endl;            
    vector<double> clear_result_layer2boot2 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2boot2 = std::max_element(clear_result_layer2boot2.begin(), clear_result_layer2boot2.end());
    auto minIt_layer2boot2 = std::min_element(clear_result_layer2boot2.begin(), clear_result_layer2boot2.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot2 << std::endl;

    Ctxt res1 = controller.add(controller.mult(controller.mult(res1sx,1),1), res1dx);              
                     
    vector<double> clear_result_layer2add1 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2add1 = std::max_element(clear_result_layer2add1.begin(), clear_result_layer2add1.end());
    auto minIt_layer2add1 = std::min_element(clear_result_layer2add1.begin(), clear_result_layer2add1.end());
    std::cout << "Maximum value: " << *maxIt_layer2add1 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add1 << std::endl;

    res1 = controller.silu(res1, scale, timing);
    cout << "After starting silu1, ciphertext level: " << res1->GetLevel() << endl;                             
    vector<double> clear_result_layer2silu2 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2silu2 = std::max_element(clear_result_layer2silu2.begin(), clear_result_layer2silu2.end());
    auto minIt_layer2silu2 = std::min_element(clear_result_layer2silu2.begin(), clear_result_layer2silu2.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu2 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer2 - Block 1---" << endl;

    if (verbose > 1) cout << "---Start: Layer2 - Block 2---" << endl;
    start = start_time();
    Ctxt res2;
    res1 = controller.bootstrap(res1, timing);
    cout << "After bootstrapping, ciphertext level: " << res1->GetLevel() <<", then starting conv3."<< endl;          
    vector<double> clear_result_layer2boot3 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2boot3 = std::max_element(clear_result_layer2boot3.begin(), clear_result_layer2boot3.end());
    auto minIt_layer2boot3 = std::min_element(clear_result_layer2boot3.begin(), clear_result_layer2boot3.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot3 << std::endl;

    res2 = controller.convbn2(res1, 5, 1, scale, timing);
    cout << "After starting layer2_conv2, ciphertext level:" << res2->GetLevel() << endl;                    
    vector<double> clear_result_layer2conv3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2conv3 = std::max_element(clear_result_layer2conv3.begin(), clear_result_layer2conv3.end());
    auto minIt_layer2conv3 = std::min_element(clear_result_layer2conv3.begin(), clear_result_layer2conv3.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv3 << std::endl;

    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res2->GetLevel() << endl;                            
    vector<double> clear_result_layer2silu3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2silu3 = std::max_element(clear_result_layer2silu3.begin(), clear_result_layer2silu3.end());
    auto minIt_layer2silu3 = std::min_element(clear_result_layer2silu3.begin(), clear_result_layer2silu3.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu3 << std::endl;

    res2 = controller.convbn2(res2, 5, 2, scale, timing);
    cout << "After starting layer2_conv2, ciphertext level:" << res2->GetLevel() << endl;             
    vector<double> clear_result_layer2conv4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2conv4 = std::max_element(clear_result_layer2conv4.begin(), clear_result_layer2conv4.end());
    auto minIt_layer2conv4 = std::min_element(clear_result_layer2conv4.begin(), clear_result_layer2conv4.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv4 << std::endl;

    res2 = controller.bootstrap(res2, timing);
    cout << "After bootstrapping, ciphertext level:" << res2->GetLevel() <<", then starting conv4."<< endl;       
    vector<double> clear_result_layer2boot4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2boot4 = std::max_element(clear_result_layer2boot4.begin(), clear_result_layer2boot4.end());
    auto minIt_layer2boot4 = std::min_element(clear_result_layer2boot4.begin(), clear_result_layer2boot4.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot4 << std::endl;
    
    res2 = controller.add(res2, res1);                                                           

    vector<double> clear_result_layer2add2 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2add2 = std::max_element(clear_result_layer2add2.begin(), clear_result_layer2add2.end());
    auto minIt_layer2add2 = std::min_element(clear_result_layer2add2.begin(), clear_result_layer2add2.end());
    std::cout << "Maximum value: " << *maxIt_layer2add2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add2 << std::endl;

    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res2->GetLevel() << endl;                               
    vector<double> clear_result_layer2silu4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2silu4 = std::max_element(clear_result_layer2silu4.begin(), clear_result_layer2silu4.end());
    auto minIt_layer2silu4 = std::min_element(clear_result_layer2silu4.begin(), clear_result_layer2silu4.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu4 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer2 - Block 2---" << endl;

    if (verbose > 1) cout << "---Start: Layer2 - Block 3---" << endl;
    start = start_time();
    Ctxt res3;
    res3 = controller.convbn2(res2, 6, 1, scale, timing);
    cout << "After starting layer2_conv2, ciphertext level: " << res3->GetLevel() << endl;                     
    vector<double> clear_result_layer2conv5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2conv5 = std::max_element(clear_result_layer2conv5.begin(), clear_result_layer2conv5.end());
    auto minIt_layer2conv5 = std::min_element(clear_result_layer2conv5.begin(), clear_result_layer2conv5.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv5 << std::endl;

    res3 = controller.silu(res3, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;                 
    vector<double> clear_result_layer2silu5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2silu5 = std::max_element(clear_result_layer2silu5.begin(), clear_result_layer2silu5.end());
    auto minIt_layer2silu5 = std::min_element(clear_result_layer2silu5.begin(), clear_result_layer2silu5.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu5 << std::endl;

    res3 = controller.bootstrap(res3, timing);
    cout << "After bootstrapping, ciphertext level:" << res3->GetLevel() <<", then starting conv6."<< endl;          
    vector<double> clear_result_layer2boot5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2boot5 = std::max_element(clear_result_layer2boot5.begin(), clear_result_layer2boot5.end());
    auto minIt_layer2boot5 = std::min_element(clear_result_layer2boot5.begin(), clear_result_layer2boot5.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot5 << std::endl;
    
    res3 = controller.convbn2(res3, 6, 2, scale, timing);
    cout << "After starting layer2_conv2, ciphertext level:" << res3->GetLevel() << endl;                      
    vector<double> clear_result_layer2conv6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2conv6 = std::max_element(clear_result_layer2conv6.begin(), clear_result_layer2conv6.end());
    auto minIt_layer2conv6 = std::min_element(clear_result_layer2conv6.begin(), clear_result_layer2conv6.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv6 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv6 << std::endl;

    res3 = controller.add(res3, res2);                                                       

    vector<double> clear_result_layer2add3 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2add3 = std::max_element(clear_result_layer2add3.begin(), clear_result_layer2add3.end());
    auto minIt_layer2add3 = std::min_element(clear_result_layer2add3.begin(), clear_result_layer2add3.end());
    std::cout << "Maximum value: " << *maxIt_layer2add3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add3 << std::endl;

    res3 = controller.silu(res3, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;                                
    vector<double> clear_result_layer2silu6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2silu6 = std::max_element(clear_result_layer2silu6.begin(), clear_result_layer2silu6.end());
    auto minIt_layer2silu6 = std::min_element(clear_result_layer2silu6.begin(), clear_result_layer2silu6.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu6 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu6 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer2 - Block 3---" << endl;

    return res3;
}

Ctxt layer3(const Ctxt& in) {

    double scale = 1;

    bool timing = verbose > 1;

    if (verbose > 1) cout << "---Start: Layer3 - Block 1---" << endl;
    auto start = start_time();
    Ctxt boot_in = controller.bootstrap(in, timing);
    cout << "After bootstrapping, ciphertext level:" << boot_in->GetLevel() <<", then starting the downsampling convolution conv1."<< endl;  
    vector<double> clear_result_boot1 = controller.decrypt_tovector(boot_in, 0);
    auto maxIt_boot1 = std::max_element(clear_result_boot1.begin(), clear_result_boot1.end());
    auto minIt_boot1 = std::min_element(clear_result_boot1.begin(), clear_result_boot1.end());
    std::cout << "Maximum value: " << *maxIt_boot1 << std::endl;
    std::cout << "Minimum value: " << *minIt_boot1 << std::endl;


    controller.clear_bootstrapping_and_rotation_keys(16384);
    controller.load_rotation_keys("rotations-layer3-downsample.bin", timing);   

    Ctxt res1sx = controller.convbn3264sx(boot_in, 7, 1, scale, timing);    
    Ctxt res1dx = controller.convbn3264dx(boot_in, 7, 1, scale, timing);     
    cout << "After starting the layer3_conv1 downsampling convolution, main path ciphertext level:" << res1sx->GetLevel() << endl;
    cout << "After starting the layer3_conv1 downsampling convolution, branch path ciphertext level:" << res1dx->GetLevel() << endl;
    vector<double> clear_result_convbnsx1 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_convbnsx1 = std::max_element(clear_result_convbnsx1.begin(), clear_result_convbnsx1.end());
    auto minIt_convbnsx1 = std::min_element(clear_result_convbnsx1.begin(), clear_result_convbnsx1.end());
    std::cout << "Maximum value: " << *maxIt_convbnsx1 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbnsx1 << std::endl;
    vector<double> clear_result_convbndx1 = controller.decrypt_tovector(res1dx, 0);
    auto maxIt_convbndx1 = std::max_element(clear_result_convbndx1.begin(), clear_result_convbndx1.end());
    auto minIt_convbndx1 = std::min_element(clear_result_convbndx1.begin(), clear_result_convbndx1.end());
    std::cout << "Maximum value: " << *maxIt_convbndx1 << std::endl;
    std::cout << "Minimum value: " << *minIt_convbndx1 << std::endl;

    controller.clear_rotation_keys();

    controller.load_bootstrapping_and_rotation_keys("rotations-layer3.bin", 16384, verbose > 1);

    res1sx = controller.silu(res1sx, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res1sx->GetLevel() << endl;                          
    vector<double> clear_result_layer2silu1 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2silu1 = std::max_element(clear_result_layer2silu1.begin(), clear_result_layer2silu1.end());
    auto minIt_layer2silu1 = std::min_element(clear_result_layer2silu1.begin(), clear_result_layer2silu1.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu1 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu1 << std::endl;

    res1sx = controller.convbn3(res1sx, 7, 2, scale, timing);
    cout << "After starting layer3_conv2, main path ciphertext level:" << res1sx->GetLevel() << endl;                   
    vector<double> clear_result_layer2conv2 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2conv2 = std::max_element(clear_result_layer2conv2.begin(), clear_result_layer2conv2.end());
    auto minIt_layer2conv2 = std::min_element(clear_result_layer2conv2.begin(), clear_result_layer2conv2.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv2 << std::endl;

    res1sx = controller.bootstrap(res1sx, timing);
    cout << "After bootstrapping, ciphertext level:" << res1sx->GetLevel() <<"，之后开始conv2"<< endl;         
    vector<double> clear_result_layer2boot2 = controller.decrypt_tovector(res1sx, 0);
    auto maxIt_layer2boot2 = std::max_element(clear_result_layer2boot2.begin(), clear_result_layer2boot2.end());
    auto minIt_layer2boot2 = std::min_element(clear_result_layer2boot2.begin(), clear_result_layer2boot2.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot2 << std::endl;

    Ctxt res1 = controller.add(controller.mult(controller.mult(res1sx,1),1), res1dx);         

    vector<double> clear_result_layer2add1 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2add1 = std::max_element(clear_result_layer2add1.begin(), clear_result_layer2add1.end());
    auto minIt_layer2add1 = std::min_element(clear_result_layer2add1.begin(), clear_result_layer2add1.end());
    std::cout << "Maximum value: " << *maxIt_layer2add1 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add1 << std::endl;

    res1 = controller.silu(res1, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res1->GetLevel() << endl;                        
    vector<double> clear_result_layer2silu2 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2silu2 = std::max_element(clear_result_layer2silu2.begin(), clear_result_layer2silu2.end());
    auto minIt_layer2silu2 = std::min_element(clear_result_layer2silu2.begin(), clear_result_layer2silu2.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu2 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer3 - Block 1---" << endl;

    if (verbose > 1) cout << "---Start: Layer3 - Block 2---" << endl;
    start = start_time();
    Ctxt res2;
    res1 = controller.bootstrap(res1, timing);
    cout << "After bootstrapping, ciphertext level:" << res1->GetLevel() <<", then starting conv3."<< endl;           
    vector<double> clear_result_layer2boot3 = controller.decrypt_tovector(res1, 0);
    auto maxIt_layer2boot3 = std::max_element(clear_result_layer2boot3.begin(), clear_result_layer2boot3.end());
    auto minIt_layer2boot3 = std::min_element(clear_result_layer2boot3.begin(), clear_result_layer2boot3.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot3 << std::endl;

    res2 = controller.convbn3(res1, 8, 1, scale, timing);
    cout << "After starting layer3_conv2, main path ciphertext level:" << res2->GetLevel() << endl;                    
    vector<double> clear_result_layer2conv3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2conv3 = std::max_element(clear_result_layer2conv3.begin(), clear_result_layer2conv3.end());
    auto minIt_layer2conv3 = std::min_element(clear_result_layer2conv3.begin(), clear_result_layer2conv3.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv3 << std::endl;

    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res2->GetLevel() << endl;                               
    vector<double> clear_result_layer2silu3 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2silu3 = std::max_element(clear_result_layer2silu3.begin(), clear_result_layer2silu3.end());
    auto minIt_layer2silu3 = std::min_element(clear_result_layer2silu3.begin(), clear_result_layer2silu3.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu3 << std::endl;

    res2 = controller.convbn3(res2, 8, 2, scale, timing);
    cout << "After starting layer3_conv2, main path ciphertext level:" << res2->GetLevel() << endl;                    
    vector<double> clear_result_layer2conv4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2conv4 = std::max_element(clear_result_layer2conv4.begin(), clear_result_layer2conv4.end());
    auto minIt_layer2conv4 = std::min_element(clear_result_layer2conv4.begin(), clear_result_layer2conv4.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv4 << std::endl;

    res2 = controller.bootstrap(res2, timing);
    cout << "After bootstrapping, ciphertext level:" << res2->GetLevel() <<", then starting conv4."<< endl;           
    vector<double> clear_result_layer2boot4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2boot4 = std::max_element(clear_result_layer2boot4.begin(), clear_result_layer2boot4.end());
    auto minIt_layer2boot4 = std::min_element(clear_result_layer2boot4.begin(), clear_result_layer2boot4.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot4 << std::endl;

    res2 = controller.add(res2, res1);                                                       

    vector<double> clear_result_layer2add2 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2add2 = std::max_element(clear_result_layer2add2.begin(), clear_result_layer2add2.end());
    auto minIt_layer2add2 = std::min_element(clear_result_layer2add2.begin(), clear_result_layer2add2.end());
    std::cout << "Maximum value: " << *maxIt_layer2add2 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add2 << std::endl;

    res2 = controller.silu(res2, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res2->GetLevel() << endl;                              
    vector<double> clear_result_layer2silu4 = controller.decrypt_tovector(res2, 0);
    auto maxIt_layer2silu4 = std::max_element(clear_result_layer2silu4.begin(), clear_result_layer2silu4.end());
    auto minIt_layer2silu4 = std::min_element(clear_result_layer2silu4.begin(), clear_result_layer2silu4.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu4 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu4 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer3 - Block 2---" << endl;

    if (verbose > 1) cout << "---Start: Layer3 - Block 3---" << endl;
    start = start_time();
    Ctxt res3;
    res3 = controller.convbn3(res2, 9, 1, scale, timing);
    cout << "After starting layer3_conv2, main path ciphertext level:" << res3->GetLevel() << endl;                
    vector<double> clear_result_layer2conv5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2conv5 = std::max_element(clear_result_layer2conv5.begin(), clear_result_layer2conv5.end());
    auto minIt_layer2conv5 = std::min_element(clear_result_layer2conv5.begin(), clear_result_layer2conv5.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv5 << std::endl;

    res3 = controller.silu(res3, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;                           
    vector<double> clear_result_layer2silu5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2silu5 = std::max_element(clear_result_layer2silu5.begin(), clear_result_layer2silu5.end());
    auto minIt_layer2silu5 = std::min_element(clear_result_layer2silu5.begin(), clear_result_layer2silu5.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu5 << std::endl;

    res3 = controller.bootstrap(res3, timing);
    cout << "After bootstrapping, ciphertext level:" << res3->GetLevel() <<", then starting conv6."<< endl;             
    vector<double> clear_result_layer2boot5 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2boot5 = std::max_element(clear_result_layer2boot5.begin(), clear_result_layer2boot5.end());
    auto minIt_layer2boot5 = std::min_element(clear_result_layer2boot5.begin(), clear_result_layer2boot5.end());
    std::cout << "Maximum value: " << *maxIt_layer2boot5 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2boot5 << std::endl;

    res3 = controller.convbn3(res3, 9, 2, scale, timing);
    cout << "After starting layer3_conv2, main path ciphertext level:" << res3->GetLevel() << endl;                 
    vector<double> clear_result_layer2conv6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2conv6 = std::max_element(clear_result_layer2conv6.begin(), clear_result_layer2conv6.end());
    auto minIt_layer2conv6 = std::min_element(clear_result_layer2conv6.begin(), clear_result_layer2conv6.end());
    std::cout << "Maximum value: " << *maxIt_layer2conv6 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2conv6 << std::endl;

    res3 = controller.add(res3, res2);                                                       

    vector<double> clear_result_layer2add3 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2add3 = std::max_element(clear_result_layer2add3.begin(), clear_result_layer2add3.end());
    auto minIt_layer2add3 = std::min_element(clear_result_layer2add3.begin(), clear_result_layer2add3.end());
    std::cout << "Maximum value: " << *maxIt_layer2add3 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2add3 << std::endl;

    res3 = controller.silu(res3, scale, timing);
    cout << "After starting silu1, ciphertext level:" << res3->GetLevel() << endl;                        
    vector<double> clear_result_layer2silu6 = controller.decrypt_tovector(res3, 0);
    auto maxIt_layer2silu6 = std::max_element(clear_result_layer2silu6.begin(), clear_result_layer2silu6.end());
    auto minIt_layer2silu6 = std::min_element(clear_result_layer2silu6.begin(), clear_result_layer2silu6.end());
    std::cout << "Maximum value: " << *maxIt_layer2silu6 << std::endl;
    std::cout << "Minimum value: " << *minIt_layer2silu6 << std::endl;

    if (verbose > 1) print_duration(start, "Total");
    if (verbose > 1) cout << "---End  : Layer3 - Block 3---" << endl;

    return res3;
}

Ctxt final_layer(const Ctxt& in) {
    
    auto start = start_time();
    bool timing = verbose > 1;
    if (verbose > 1) cout << "---Start: Final_Layer---" << endl;
    controller.clear_bootstrapping_and_rotation_keys(16384);
    controller.load_rotation_keys("rotations-finallayer.bin", timing); 
    Ctxt res = controller.rotsum1(in);

    double scale = 0.015625;
    Ptxt gamma1 = controller.encode(read_values_from_file("../weights/fc_weight_1.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma2 = controller.encode(read_values_from_file("../weights/fc_weight_2.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma3 = controller.encode(read_values_from_file("../weights/fc_weight_3.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma4 = controller.encode(read_values_from_file("../weights/fc_weight_4.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma5 = controller.encode(read_values_from_file("../weights/fc_weight_5.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma6 = controller.encode(read_values_from_file("../weights/fc_weight_6.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma7 = controller.encode(read_values_from_file("../weights/fc_weight_7.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma8 = controller.encode(read_values_from_file("../weights/fc_weight_8.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma9 = controller.encode(read_values_from_file("../weights/fc_weight_9.txt", scale), res->GetLevel(), 16384);
    Ptxt gamma10 = controller.encode(read_values_from_file("../weights/fc_weight_10.txt", scale), res->GetLevel(), 16384);


    Ctxt res1 = controller.mult(res, gamma1);
    res1 = controller.rotsum2(res1);

    
    Ctxt res2 = controller.mult(res, gamma2);
    res2 = controller.rotsum2(res2);    

    
    Ctxt res3 = controller.mult(res, gamma3); 
    res3 = controller.rotsum2(res3);   
   
    Ctxt res4 = controller.mult(res, gamma4);  
    res4 = controller.rotsum2(res4);  
    
    Ctxt res5 = controller.mult(res, gamma5);   
    res5 = controller.rotsum2(res5); 
    
    Ctxt res6 = controller.mult(res, gamma6);   
    res6 = controller.rotsum2(res6); 
    
    Ctxt res7 = controller.mult(res, gamma7);   
    res7 = controller.rotsum2(res7); 
    
    Ctxt res8 = controller.mult(res, gamma8);   
    res8 = controller.rotsum2(res8); 
    
    Ctxt res9 = controller.mult(res, gamma9);    
    res9 = controller.rotsum2(res9);
    
    Ctxt res10 = controller.mult(res, gamma10);   
    res10 = controller.rotsum2(res10); 

    cout << "The fully connected layer is fine, ciphertext level:" << res10->GetLevel() << endl; 
    if (verbose > 1) cout << "---End  : Final_Layer---" << endl;
    if (verbose > 1) print_duration(start, "Total");

    
    vector<double> result_0 = controller.decrypt_tovector(res1, 0);append_vector_first_element_to_txt(result_0,"result_0");
    vector<double> result_1 = controller.decrypt_tovector(res2, 0);append_vector_first_element_to_txt(result_1,"result_1");
    vector<double> result_2 = controller.decrypt_tovector(res3, 0);append_vector_first_element_to_txt(result_2,"result_2");
    vector<double> result_3 = controller.decrypt_tovector(res4, 0);append_vector_first_element_to_txt(result_3,"result_3");
    vector<double> result_4 = controller.decrypt_tovector(res5, 0);append_vector_first_element_to_txt(result_4,"result_4");
    vector<double> result_5 = controller.decrypt_tovector(res6, 0);append_vector_first_element_to_txt(result_5,"result_5");
    vector<double> result_6 = controller.decrypt_tovector(res7, 0);append_vector_first_element_to_txt(result_6,"result_6");
    vector<double> result_7 = controller.decrypt_tovector(res8, 0);append_vector_first_element_to_txt(result_7,"result_7");
    vector<double> result_8 = controller.decrypt_tovector(res9, 0);append_vector_first_element_to_txt(result_8,"result_8");
    vector<double> result_9 = controller.decrypt_tovector(res10, 0);append_vector_first_element_to_txt(result_9,"result_9");

    vector<double> result;
    result.reserve(10);
    result.push_back(result_0[0]);result.push_back(result_1[0]);result.push_back(result_2[0]);result.push_back(result_3[0]);result.push_back(result_4[0]);
    result.push_back(result_5[0]);result.push_back(result_6[0]);result.push_back(result_7[0]);result.push_back(result_8[0]);result.push_back(result_9[0]);

    append_vector_to_txt(result,"result");

    auto max_element_iterator = std::max_element(result.begin(), result.end());
    int index_max = distance(result.begin(), max_element_iterator);
    
    cout << "The input image "<< input_filename << " is classified as " << YELLOW_TEXT << utils::get_class(index_max) << RESET_COLOR << "" << endl;
    
    ofstream outfile("classified_results.txt", ios::app); 

    if (!outfile.is_open()) {
        cerr << "Failed to open file!" << endl;
        exit(1);
    }


    outfile << input_filename << "     " << utils::get_class(index_max) << endl;


    outfile.close();

    cout << "Successfully wrote to classified_results.txt" << endl;


    return res;
}

vector<double> read_image(const char *filename) {
    int width = 32;
    int height = 32;
    int channels = 3;
    unsigned char* image_data = stbi_load(filename, &width, &height, &channels, 0);

    if (!image_data) {
        cerr << "Could not load the image in " << filename << endl;
        return vector<double>();
    }

	// Total ciphertext space: 16 * 32 * 32 = 16,384. That is 128 * 128, where 16-channel data occupies 4x4 block positions.
	// First, dense packing.
    vector<double> x_1(1024, 0.0);
    vector<double> x_2(1024, 0.0);
    vector<double> x_3(1024, 0.0);
    vector<double> x_4(1024, 0.0);
    vector<double> x_5(1024, 0.0);
    vector<double> x_6(1024, 0.0);
    vector<double> x_7(1024, 0.0);
    vector<double> x_8(1024, 0.0);
    vector<double> x_9(1024, 0.0);
    vector<double> x_10(1024, 0.0);
    vector<double> x_11(1024, 0.0);
    vector<double> x_12(1024, 0.0);
    vector<double> x_13(1024, 0.0);
    vector<double> x_14(1024, 0.0);
    vector<double> x_15(1024, 0.0);
    vector<double> x_16(1024, 0.0);

    for (int i = 0; i < 1024; ++i) {
        x_1[i] = (static_cast<double>(image_data[3 * i]) / 255.0f - 0.4914) / 0.2023; 
    }
    for (int i = 0; i < 1024; ++i) {
        x_2[i] = (static_cast<double>(image_data[1 + 3 * i]) / 255.0f - 0.4822) / 0.1994;
    }
    for (int i = 0; i < 1024; ++i) {
        x_5[i] = (static_cast<double>(image_data[2 + 3 * i]) / 255.0f - 0.4465) / 0.2010;
    }

    vector<double> combinedMatrix(16384, 0.0);

    int idx1 = 0, idx2 = 0, idx3 = 0, idx4 = 0;
    int idx5 = 0, idx6 = 0, idx7 = 0, idx8 = 0;
    int idx9 = 0, idx10 = 0, idx11 = 0, idx12 = 0;
    int idx13 = 0, idx14 = 0, idx15 = 0, idx16 = 0;


    for (int i = 0; i < 128; i += 4) { 
        for (int j = 0; j < 128; j += 4) { 

            int baseIndexRow0 = i * 128 + j;
            int baseIndexRow1 = (i + 1) * 128 + j;
            int baseIndexRow2 = (i + 2) * 128 + j;
            int baseIndexRow3 = (i + 3) * 128 + j;


            combinedMatrix[baseIndexRow0]     = x_1[idx1++];
            combinedMatrix[baseIndexRow0 + 1] = x_2[idx2++];
            combinedMatrix[baseIndexRow0 + 2] = x_3[idx3++];
            combinedMatrix[baseIndexRow0 + 3] = x_4[idx4++];

            combinedMatrix[baseIndexRow1]     = x_5[idx5++];
            combinedMatrix[baseIndexRow1 + 1] = x_6[idx6++];
            combinedMatrix[baseIndexRow1 + 2] = x_7[idx7++];
            combinedMatrix[baseIndexRow1 + 3] = x_8[idx8++];

            combinedMatrix[baseIndexRow2]     = x_9[idx9++];
            combinedMatrix[baseIndexRow2 + 1] = x_10[idx10++];
            combinedMatrix[baseIndexRow2 + 2] = x_11[idx11++];
            combinedMatrix[baseIndexRow2 + 3] = x_12[idx12++];

            combinedMatrix[baseIndexRow3]     = x_13[idx13++];
            combinedMatrix[baseIndexRow3 + 1] = x_14[idx14++];
            combinedMatrix[baseIndexRow3 + 2] = x_15[idx15++];
            combinedMatrix[baseIndexRow3 + 3] = x_16[idx16++];
        }
    }
	
    stbi_image_free(image_data);

    return combinedMatrix;
}

void check_arguments(int argc, char *argv[]) {
    generate_context = -1;
    verbose = 0;

    for (int i = 1; i < argc; ++i) {

        if (string(argv[i]) == "verbose") {
            if (i + 1 < argc) { 
                verbose = atoi(argv[i + 1]);
            }
        }
    }


    for (int i = 1; i < argc; ++i) {
        if (string(argv[i]) == "load_keys") {
            if (i + 1 < argc) {
                controller.parameters_folder = "../keys";
                if (verbose > 1) cout << "Context folder set to: \"" << controller.parameters_folder << "\"." << endl;
                generate_context = 0;
            }
        }

        if (string(argv[i]) == "generate_keys") {
            if (i + 1 < argc) {
                string folder = "";
                if (string(argv[i+1]) == "1") {
                    folder = "../keys";
                    generate_context = 1;
                } else if (string(argv[i+1]) == "2") {
                    folder = "keys_exp2";
                    generate_context = 2;
                } else {
                    cerr << "Set a proper value for 'generate_keys'." << endl;
                    exit(1);
                }

                controller.parameters_folder = folder;
                if (verbose > 1) cout << "Context folder set to: \"" << controller.parameters_folder << "\"." << endl;
            }
        }

        if (string(argv[i]) == "input") {
            if (i + 1 < argc) {
                input_filename = "../" + string(argv[i + 1]);
                if (verbose > 1) cout << "Input image set to: \"" << input_filename << "\"." << endl;
            }
        }


    }

}

void print_max_min_value(const Ctxt& in) {

    std::vector<double> clear_result = controller.decrypt_tovector(in, 0);


    auto maxIt = std::max_element(clear_result.begin(), clear_result.end());
    auto minIt = std::min_element(clear_result.begin(), clear_result.end());

    std::cout << "Maximum value: " << *maxIt << std::endl;
    std::cout << "Minimum value: " << *minIt << std::endl;
}

void save_vector_to_txt(const std::vector<double>& vec, const std::string& filename) {

    std::ofstream out_file(filename);


    if (!out_file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }


    for (const double& value : vec) {
        out_file << value << std::endl; 
    }


    out_file.close();

    std::cout << "Data saved to " << filename << std::endl;
}

void append_vector_to_txt(const std::vector<double>& vec, const std::string& filename) {

    std::ofstream out_file(filename, std::ios::app);

    if (!out_file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }


    for (const double& value : vec) {
        out_file << value << std::endl;  
    }

    out_file.close();

    std::cout << "Data appended to " << filename << std::endl;
}

void append_vector_first_element_to_txt(const std::vector<double>& vec, const std::string& filename) {

    std::ofstream out_file(filename, std::ios::app);


    if (!out_file) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }


    if (!vec.empty()) {
        out_file << vec[0] << std::endl;  
    } else {
        std::cerr << "Vector is empty, nothing to append." << std::endl;
    }


    out_file.close();

    std::cout << "First element appended to " << filename << std::endl;
}
